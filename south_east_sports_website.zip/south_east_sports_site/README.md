# South East Sports — starter website

This is a static, responsive starter website for South East Sports.

## Files
- `index.html` — site content and structure
- `styles.css` — brand styling and responsive layout
- `script.js` — mobile navigation and current year
- `assets/ses-mark.svg` — simple SES monogram favicon/logo

## Before launch
1. Replace `YOUR-EMAIL@example.com` in `index.html` with an email address you control.
2. Replace all introductory placeholder copy with verified reporting before describing it as news.
3. Replace image URLs with your own sports photos or images you have permission to publish. Remote demo photos require an internet connection and may change availability.
4. Update the About page and coverage claims to reflect the publication's actual work.
5. Check that you have permission to use the South East Sports name and logo before investing in paid materials.
6. Test on phone and desktop, including every navigation and contact link.

## Free publishing option: GitHub Pages
1. Create a GitHub account if needed.
2. Create a new public repository named `south-east-sports`.
3. Upload `index.html`, `styles.css`, `script.js`, and the `assets` folder to the repository root.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose deploy from a branch, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and use the URL shown in Settings → Pages.
7. Test the live URL on your phone. A custom domain is optional and costs extra.

GitHub Pages is for static sites. This starter has no CMS or database. To add articles, edit the HTML and upload the changed files, or later move to a CMS if publishing frequently becomes cumbersome.

## Important
- This starter does not include a backend, user accounts, analytics, a newsletter system, or an actual photo upload feature.
- The mailto contact link opens the visitor's email app; it is not a hosted contact form.
- Use only photos you own or are authorized to publish. Verify scores, quotes, names, and statistics before posting.
